package com.projek.tokweb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TokwebApplicationTests {

	@Test
	void contextLoads() {
	}

}
