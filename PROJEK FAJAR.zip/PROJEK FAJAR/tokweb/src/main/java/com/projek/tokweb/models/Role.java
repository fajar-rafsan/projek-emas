package com.projek.tokweb.models;

public enum Role {
    ADMIN, USER
}
