package com.projek.tokweb.models.goldPrice;

public enum GoldPriceEnum {
    ADMIN,SISTEM
}
